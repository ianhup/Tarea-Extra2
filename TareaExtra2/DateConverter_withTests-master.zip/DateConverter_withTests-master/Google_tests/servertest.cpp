#include "gtest/gtest.h"
#include "vector"
#include "iostream"
#include "MOYFNetworking/include/MOYFNetworking/server/tcp_server.h"
#include "MOYFNetworking/include/MOYFNetworking/server/tcp_connection.h"
#include "MOYFNetworking/include/MOYFNetworking/client/tcp_client.h"
#include "gmock/gmock.h"


using namespace std;
using ::testing::AtLeast;
using ::testing::Return;
using ::testing::_;


class DataBaseConnect {
public:
    using MessageHandler = std::function<void(std::string)>;
    using ErrorHandler = std::function<void()>;

    virtual void startAccept(){
    }

    virtual void Start(MessageHandler&& messageHandler){
    }
    virtual void Broadcast(const std::string& message){
    }
};



class tester{
public:
    using OnLeaveHandler = std::function<void(MOYF::TCPConnection::pointer)>;
    using OnClientMessageHandler = std::function<void(std::string)>;
    OnLeaveHandler OnLeave;
    OnClientMessageHandler OnClientMessage;

    std::optional<boost::asio::ip::tcp::socket> _socket;
    std::unordered_set<MOYF::TCPConnection::pointer> _connections {};

    using MessageHandler = std::function<void(std::string)>;
    using ErrorHandler = std::function<void()>;


    void Broadcast(DataBaseConnect* obj, const std::string& message){
        obj->Broadcast(message);
    }
    void Start(DataBaseConnect* obj,MessageHandler&& messageHandler){
        obj->Start([this](const std::string& message) { if (OnClientMessage) OnClientMessage(message); });
    }
};



class MockDB : public DataBaseConnect {
public:
    MOCK_METHOD1(Broadcast, void(const std::string &message));
    MOCK_METHOD1(Start, void(MessageHandler&& messageHandler));

};



TEST(MyDBTest, dataTest){
    MockDB mdb;
    tester cut;

    std::string trydata = "data";
    EXPECT_CALL(mdb,Broadcast(_));
    EXPECT_CALL(mdb,Start(_));
    mdb.Broadcast(trydata);
    cut.Broadcast(&mdb,trydata);
    




}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}